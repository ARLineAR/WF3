<?php
 /*
    Exercice 1 : « On se présente ! »
Créer un tableau en PHP contenant les infos suivantes :
● Prénom
● Nom
● Adresse
● Code Postal
● Ville
● Email
● Téléphone
● Date de naissance au format anglais (YYYY-MM-DD)
A l’aide d’une boucle, afficher le contenu de ce tableau (clés + valeurs) dans une liste HTML.
La date sera affichée au format français (DD/MM/YYYY).
Bonus :
Gérer l’affichage de la date de naissance à l’aide de la classe DateTime

 
 */
echo '<h1> On se présente !</h1>';

 $contact= array('Prénom'=>'Aline', 'Nom'=>'Rambier', 'Adresse'=>'18, rue des Grandes Vignes', 'Code Postal'=>'91310', 'Ville'=>'Montlhéry', 'Email'=>'alinerambier@gmail.com', 'Téléphone'=>'0679042838', 'Date de naissance'=>'1990-09-25');

 
function switchDate($date, $format) { // la fonction switchDate() permet d'inverser le format ('US' ou 'FR') de la date
    
    $objetDate = new DateTime($date);

    if ($format == 'FR') {
        return $objetDate->format('d-m-Y') . '<br>';

    }elseif ($format =='US') {
        return $objetDate->format('Y-m-d') . '<br>';
    }

}

echo '<ul>'; // Grâce au balises <ul><li></li></ul>, on affiche la liste des clés ($key) et les valeurs ($valeur)
    foreach($contact as $key => $value){ // la boucle foreach permet de parcourir les indices et les valeurs du tableau PHP $contact () 

         if($key =='Date de naissance' ) { // condition pour l'affichage de la date de naissance dans un premier temps

            echo '<li>'.'<span style="font-weight: bold">'. $key .'</span>'. ': ' . switchDate('1990-09-25','FR') . '</li>'; 


         } else{ // pour tous les autres champs excepté 'Date de naissance'
            echo '<li>'. '<span style="font-weight: bold">'. $key .'</span>'. ': ' . $value. '</li>'; 
         }
             
    }

  echo '</ul>';

?>

