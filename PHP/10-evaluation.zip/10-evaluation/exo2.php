<?php

/*
    Exercice 2 : « On part en voyage »
Créer une fonction permettant de convertir un montant en euros vers un montant en dollars
américains.
Cette fonction prendra deux paramètres :
● Le montant de type int ou float
● La devise de sortie (uniquement EUR ou USD).
Si le second paramètre est “USD”, le résultat de la fonction sera, par exemple :
1 euro = 1.085965 dollars américains
Il faut effectuer les vérifications nécessaires afin de valider les paramètres.

*/

echo '<h1>On part en voyage</h1>';

$montant = '';
$devise ='' ; // on déclare les deux paramètres ($montant et $devise) de la fonction conversionDevise() avant de la définir

function conversionDevise($montant, $devise){


    if($devise == ' USD'){
    
     $deviseFinale = $montant / 1.085965 . ' EUR';


    }elseif($devise ==' EUR'){

     $deviseFinale = $montant * 1.085965 . ' USD';
    }

    return $montant . $devise . ' correspond(ent) à '. $deviseFinale;
}

echo conversionDevise(15, ' EUR') . '<br>'; // permet d'afficher la conversion en dollars américains
echo conversionDevise(15, ' USD'); // permet d'afficher la conversion en euros


