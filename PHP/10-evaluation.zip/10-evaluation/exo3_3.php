<?php

/*
Étape 3 :
Créer une page listant dans un tableau HTML les films présents dans la base de données.
Ce tableau ne contiendra, par film, que le nom du film, le réalisateur et l’année de
production.
Une colonne de ce tableau contiendra un lien « plus d’infos » permettant de voir la fiche
d’un film dans le détail.
Étape 4 :
Créer une page affichant le détail d’un film de manière dynamique. Si le film n’existe pas,
une erreur sera affichée.

*/


$infos = '';

$pdo = new PDO('mysql:host=localhost;dbname=exercice_3', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8')); //conexion à la BDD (exercie_3)


$query = $pdo->prepare('SELECT * FROM movies'); // préparation de la requête 
$query->execute(); // exécution
$infos .= '<h1>Liste des films</h1> 
			 <table border="1">'; // Création de la table HTML
		$infos .= '<tr>
						<th>Titre</th>
						<th>Réalisateur</th>
						<th>Année de production</th>
						<th>Plus d\' infos</th>
					</tr>';

while ($movies = $query->fetch(PDO::FETCH_ASSOC)){ // la boucle while permet de parcourir les champs "Titre", "Réalisateur", "Année de production" et "Plus d'infos"; le fetch permet dde transformer $movies en array associatif
		$infos .= '<tr>
						<td>'. $movies['title'] .'</td>
						<td>'. $movies['director'] .'</td>
						<td>'. $movies['year_of_prod'] .'</td>
						<td>
							<a href="?id_film='. $movies['id_film'] .'">Plus d\'infos</a>
						</td>
					</tr>';
	}			
			
$infos .= '</table>';



if(isset($_GET['id_film'])){ // si l'id_film est correct 
	
	$query = $pdo->prepare('SELECT * FROM movies WHERE id_film = :id_film');
	$query->bindParam(':id_film', $_GET['id_film'], PDO::PARAM_INT);
	$query->execute();
	$film = $query->fetch(PDO::FETCH_ASSOC);

	$infos .= '<h1>Détail d\'un film</h1>';
	if (!empty($film)) { // si le film existe, on affiche son détail
		$infos .= '<p>Titre : '. $film['title'] .'</p>';
		$infos .= '<p>Acteurs : '. $film['actors'] .'</p>';
		$infos .= '<p>Réalisateur : '. $film['director'] .'</p>';
		$infos .= '<p>Produtceur : '. $film['producer'] .'</p>';
        $infos .= '<p>Synopsis : '. $film['storyline'] .'</p>';
		$infos .= '<p>Année de production : '. $film['year_of_prod'] .'</p>';
		$infos .= '<p>Langue : '. $film['language'] .'</p>';
		$infos .= '<p>Catégorie : '. $film['category'] .'</p>';
		


	} else {
		$infos .= '<div>Ce film n\'existe pas</div>';
	}

}

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Liste des films</title>
</head>
<body>
	<?php echo $infos; ?>
</body>
</html>