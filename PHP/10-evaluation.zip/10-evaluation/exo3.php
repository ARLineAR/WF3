<?php

/*

Exercice 3 : « Et si on regardait un film ? »
Vous travaillez pour un cinéma et devez créer une base de données de film. Votre base de
données s’appellera « exercice_3 ». Vous devrez ensuite créer un script qui permettra
d’ajouter et d’afficher des films. Suivez les étapes.
Étape 1 :
Cette table, nommée “movies” sera composée des champs suivants :
● title (varchar) : le nom du film
● actors (varchar) : les noms d’acteurs
● director (varchar) : le nom du réalisateur
● producer (varchar) : le nom du producteur
● year_of_prod (year) : l’année de production
● language (varchar) : la langue du film
● category (enum) : la catégorie du film
● storyline (text) : le synopsis du film
● video (varchar) : le lien de la bande annonce du film
N’oubliez pas de créer un ID pour chaque film et de l’auto-incrémenter.


Étape 2 :
Créer un formulaire permettant d’ajouter un film et effectuer les vérifications nécessaires.
Prérequis :
● Les champs “titre, nom du réalisateur, acteurs, producteur et synopsis” comporteront
au minimum 5 caractères.
● Les champs : année de production, langue, category, seront obligatoirement un
menu déroulant
● Le lien de la bande annonce sera obligatoirement une URL valide
● En cas d’erreurs de saisie, des messages d’erreurs seront affichés en rouge
Chaque film sera ajouté à la base de données créée. Un message de réussite confirmera
l’ajout du film.
Évaluation pratique PHP
Temps imparti : 4h00


Étape 3 :
Créer une page listant dans un tableau HTML les films présents dans la base de données.
Ce tableau ne contiendra, par film, que le nom du film, le réalisateur et l’année de
production.
Une colonne de ce tableau contiendra un lien « plus d’infos » permettant de voir la fiche
d’un film dans le détail.
Étape 4 :
Créer une page affichant le détail d’un film de manière dynamique. Si le film n’existe pas,
une erreur sera affichée.



*/


$contenu = ""; // la variable $contenu permet d'afficher les messages d'erreur
$language = array('Anglais', 'Français', 'Espagnol', 'Italien'); // $language est un tableau PHP qui permet de regrouper les différentes langues à choisir dans le champ "Langue"
$category = array('Action', 'Comédie', 'Drame', 'Fantastique', 'Documentaire'); // $category est un tableau PHP qui permet de regrouper les différentes catégories à choisir dans le champ "Catégorie"

$pdo = new PDO('mysql:host=localhost;dbname=exercice_3', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8')); // connexion à la base de deonnée "exercice_3"


if(!empty($_POST)){ // Vérification des champs du formulaire (si vides, on génère un des messages d'erreur')

    if(strlen($_POST['title']) < 5 || ($_POST['title']) > 20){

        $contenu .= '<div>Le champ "Titre" doit comporter au moins 5 caractères</div>';
    }

    if(strlen($_POST['actors']) < 5 || ($_POST['actors']) > 255){

        $contenu .= '<div>Le champ "Acteurs" doit comporter au moins 5 caractères</div>';
    }

    if(strlen($_POST['director']) < 5 || ($_POST['director']) > 20){

        $contenu .= '<div>Le champ "Réalisateur" doit comporter au moins 5 caractères</div>';
    }

    if(strlen($_POST['producer']) < 5 || ($_POST['producer']) > 20){

        $contenu .= '<div>Le champ "Producteur" doit comporter au moins 5 caractères</div>';
    }

    if(strlen($_POST['storyline']) < 5 ){

        $contenu .= '<div>Le champ "Synopsis" doit comporter au moins 5 caractères</div>';
    }

    if (!(is_numeric($_POST['year_of_prod']) && checkdate('01', '01', $_POST['year_of_prod']))){
		$contenu .= '<div>L\'année de production n\'est pas valide</div>';
	}


    if (!in_array($_POST['language'], $language)){

        $contenu .= '<div>Vous devez sélectioner une langue</div>';
    }
    

    if (!in_array($_POST['category'], $category)){

        $contenu .= '<div>Vous devez sélectioner une categorie</div>';

    }

    

    if(empty($contenu)){ // Pour pouvoir enregistrer un film dans la base de donnée, il faut que les messages d'erreur soient vides


        foreach($_POST as $indices => $valeurs)
		{
			$_POST[$indices] = htmlspecialchars($valeurs, ENT_QUOTES); // htmlspecialchars est une méthode qui permet de convertir les caractères spéciaux en caractères HTML
		}


		$query = $pdo->prepare('INSERT INTO movies (title, director, actors, producer, storyline, year_of_prod, language, category) VALUES(:title, :director, :actors, :producer, :storyline, :year_of_prod, :language, :category)'); // préparation de la requête $query
		$query->bindParam(':title', $_POST['title'], PDO::PARAM_STR);
		$query->bindParam(':director', $_POST['director'], PDO::PARAM_STR);
		$query->bindParam(':actors', $_POST['actors'], PDO::PARAM_STR);
		$query->bindParam(':producer', $_POST['producer'], PDO::PARAM_STR);
		$query->bindParam(':storyline', $_POST['storyline'], PDO::PARAM_STR);
		$query->bindParam(':year_of_prod', $_POST['year_of_prod'], PDO::PARAM_INT);
		$query->bindParam(':language', $_POST['language'], PDO::PARAM_STR);
		$query->bindParam(':category', $_POST['category'], PDO::PARAM_STR);
		

		$success = $query->execute(); // exécution de la requête

		if ($success) {
			$contenu .= '<p>Le film a été enregistré avec succés<p>';
		} else {
			$contenu .= '<div>Erreur lors de l\'enregistrement<div>';
		}





    } // Fin du if(empty($contenu))






    

} // Fin du if(!empty($_POST))






?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Et si on regardait un film ? </title>
        <style>
            div{
                color : red;
            }
        </style>
    </head>
    <body>
        <h1>Et si on regardait un film ? </h1>
        <?php echo $contenu . '<br>'; // permet d'afficher les messages d'erreur au-dessus du formulaire ?> 
        <form method="post" action="">
        
            <label for="title">Titre</label><br>
            <input type="text" name="title" id="title"><br><br>

            <label for="actors">Acteurs</label><br>
            <input type="text" name="actors" id="actors"><br><br>

            <label for="director">Réalisateur</label><br>
            <input type="text" name="director" id="director"><br><br>


            <label for="producer">Producteur</label><br>
            <input type="text" name="producer" id="producer"><br><br>

            <label for="storyline">Synopsis</label><br>
            <textarea name="storyline" id="storyline"></textarea><br><br>

            <label for="year_of_prod">Année de production</label><br>
            <select name="year_of_prod" id="year_of_prod"><br><br>
                <?php
                for($year=date('Y'); $year >= date('Y')-130; $year--){
                    echo "<option value=$year>$year</option>";
                }              
                ?>        
            </select><br><br>

            <label for="language">Langue</label><br>
            <select name="language" id="language">
                <?php
                foreach($language as $index => $valeur){
                     echo "<option value=$valeur>$valeur</option>";
                }
                ?>        
            </select><br><br>

             <label for="category">Catégorie</label><br>
            <select name="category" id="category">
                <?php 
                foreach($category as $key => $value){
                     echo "<option value=$value>$value</option>";
                }
                ?>        
            </select><br><br>

            <label for="video">Vidéo</label><br>
           <a href="http://localhost/PHP/10-evaluation/exo1">Bande-annonce</a><br><br>
            

            <input type="submit">
        
        
        
        
        </form>
    </body>
</html>